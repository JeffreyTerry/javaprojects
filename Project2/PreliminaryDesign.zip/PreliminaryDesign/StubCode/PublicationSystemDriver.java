/**
 * Project #2
 * CS 2334, Section 011
 * 9/19/2013
 * <P>
 * This class drives it all.
 * </P>
 * @version 1.0
 */
public class PublicationSystemDriver 
{
	public static void main(String args[])
	{
		PublicationSystemGUI gooey = new PublicationSystemGUI(520, 680);
		gooey.open();
	}
}
