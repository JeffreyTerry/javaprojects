/**
 * Project #1
 * CS 2334, Section 10
 * 9/9/13
 * <P>
 * This class uses a DataSystemGUI to provide the user with a user-friendly virtual magazine data system.
 * </P>
 * @version 1.0
 */

public class DataSystemDriver
{
	public static void main(String args[]){
		DataSystemGUI app = new DataSystemGUI();
		for(int i = 0; i < args.length; i++)
			app.loadMagazines(args[i]);
		app.open();
	}
}
