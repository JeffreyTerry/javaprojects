import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;


/**
 * Lab #3
 * CS 2334, Section 0??
 * September 12, 2013
 * <P>
 * This class provides a very simple model for an academic paper.
 * </P>
 * @author Leave Blank
 * @version 1.0
 */
public class AcademicPaper implements Comparable<AcademicPaper>{
		
	/** The title of the paper. */
	private String title;
	
	/** The names of the authors of the paper */
	private ArrayList<String> authorNames;

	/** The paper's date of publication. */
	private Calendar dateOfPublication;

	
	/**
	 * This is the default constructor for the class.
	 */   
	public AcademicPaper() {
		title = "";
		authorNames = null;
		dateOfPublication = null;
	}

	/**
	 * This is a constructor for the class. 
	 * It instantiates the class with user-supplied values.
	 * This version of the constructor is used when only one author name is provided.
	 * <P>
	 * @param        title        	    The title of the paper.
	 * @param        authorName         The name of the author.
	 * @param        dateOfPublication  When the paper was published.
	 */   
	public AcademicPaper(String title, String authorName, Calendar dateOfPublication) {
		this.title = title;
		this.authorNames = new ArrayList<String>();
		this.dateOfPublication = dateOfPublication;
		
		authorNames.add(authorName);
	}
	
	/**
	 * This is a constructor for the class. 
	 * It instantiates the class with user-supplied values.
	 * This version of the constructor is used when multiple authors names are provided.
	 * <P>
	 * @param        title        	    The title of the paper.
	 * @param        authorNames        The names of the authors.
	 * @param        dateOfPublication  When the paper was published.
	 */   
	public AcademicPaper(String title, ArrayList<String> authorNames, Calendar dateOfPublication) {
		this.title = title;
		this.authorNames = authorNames;
		this.dateOfPublication = dateOfPublication;
	}
	
	/**
	 * This method returns the attributes of this class as a single string.
	 * </P>
	 * @return            String representing the contents of this object.
	 */
	public String toString(){
		String toReturn = "{Title - " + title + "; Authors - ";
		for(String author: authorNames){
			toReturn += author + ", ";
		}
		toReturn = toReturn.substring(0, toReturn.length() - 2);
		toReturn += "; Date Published - " + dateOfPublication.getTime() + "}";
		return toReturn; // Make sure you replace this return statement.	
	}


	/**
	 * This method compares an instance of this AcademicPaper, with another
	 * instance of AcademicPaper.
	 * <P>
	 * Algorithm:<br>
	 * ????
	 * </P>
	 * @param             obj         The object to which we are comparing
	 *                                this instance of AcademicPaper.
	 * @return            ?????????
	 */    
	public int compareTo(AcademicPaper obj){
		ArrayList<String> sortedNames = new ArrayList<String>(authorNames);
		Collections.sort(sortedNames);
		ArrayList<String> sortedObjNames = new ArrayList<String>(obj.authorNames);
		Collections.sort(sortedObjNames);
		//Compare authors
		for(int i = 0; i < Math.min(sortedNames.size(), sortedObjNames.size()); i++){
			if(sortedNames.get(i).compareTo(sortedObjNames.get(i)) != 0){
				return sortedNames.get(i).compareTo(sortedObjNames.get(i));
			}
		}
		if(sortedNames.size() < sortedObjNames.size()){
			return -1;
		}
		else if(sortedNames.size() > sortedObjNames.size()){
			return 1;
		}
		
		//Compare titles
		return title.compareTo(obj.title);
	}
}
