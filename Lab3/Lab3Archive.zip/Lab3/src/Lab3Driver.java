import java.util.*;
/**
 * Lab #3
 * CS 2334, Section 0??
 * September 12, 2013
 * <P>
 * This class implements a program that tests the AcademicPaper class code.
 * </P>
 * @author Leave Blank
 * @version 1.0
 */
public class Lab3Driver {

	/**
	 * This is the main method for this driver program. Since this is a
	 * simple program, all of our code will be in the main method.
	 * Typically this would be a bad design, but we are just testing out
	 * some features of Java.
	 * <P>
	 * Algorithm<br>
	 * Test out the AcademicPaper class and an ArrayList of them to help your
	 * understanding of creating, sorting, and searching lists.
	 * </P>
	 * @param             args       Contains the command line arguments.
	 */

	public static void main(String[] args) {
		ArrayList<AcademicPaper> papers = new ArrayList<AcademicPaper>();

		/* 
		 * Instantiate eight objects of type AcademicPaper and add them
		 * to the list papers. 
		 * I have created and added the first academic paper for you. :)
		 */        

		/* This is a list of authors that we create for one paper. */
		ArrayList<String> authorsStringMatching = new ArrayList<String>();
		authorsStringMatching.add("Donald E. Knuth");
		authorsStringMatching.add("James H. Morris Jr.");
		authorsStringMatching.add("Vaughan R. Pratt");
		
		AcademicPaper stringMatchingPaper = new AcademicPaper("Fast Pattern Matching in Strings", 
				authorsStringMatching, new GregorianCalendar(1977, 03, 21));

		/* This is a list of authors that we create for one paper. */
		ArrayList<String> authorsStringMatching2 = new ArrayList<String>();
		authorsStringMatching2.add("Donald E. Knuth");
		authorsStringMatching2.add("James H. Morris Jr.");
		authorsStringMatching2.add("Vaughan R. Pratt");
		
		AcademicPaper stringMatchingPaper2 = new AcademicPaper("Fast Pattern Matching in Strings 2", 
				authorsStringMatching2, new GregorianCalendar(1977, 03, 21));

		/* This is a list of authors that we create for one paper. */
		ArrayList<String> authorsStringMatching3 = new ArrayList<String>();
		authorsStringMatching3.add("Donald E. Knuth");
		authorsStringMatching3.add("Vaughan R. Pratt");
		
		AcademicPaper stringMatchingPaper3 = new AcademicPaper("Fast A Pattern Matching in Strings", 
				authorsStringMatching3, new GregorianCalendar(1977, 03, 21));

		/* This is a list of authors that we create for one paper. */
		ArrayList<String> authorsStringMatching4 = new ArrayList<String>();
		authorsStringMatching4.add("Donald E. Knuth");
		authorsStringMatching4.add("James t");
		
		AcademicPaper stringMatchingPaper4 = new AcademicPaper("Fast Pa in Strings", 
				authorsStringMatching4, new GregorianCalendar(1977, 03, 21));

		/* This is a list of authors that we create for one paper. */
		ArrayList<String> authorsStringMatching5 = new ArrayList<String>();
		authorsStringMatching5.add("Donald E. Knuth");
		authorsStringMatching5.add("James H. Morris Jr.");
		authorsStringMatching5.add("Vaughan R. Pratt");
		
		AcademicPaper stringMatchingPaper5 = new AcademicPaper("Fast Pattern Matching in Strings", 
				authorsStringMatching5, new GregorianCalendar(1977, 03, 21));

		/* This is a list of authors that we create for one paper. */
		ArrayList<String> authorsStringMatching6 = new ArrayList<String>();
		authorsStringMatching6.add("James H. Morris Jr.");
		authorsStringMatching6.add("Vaughan R. Pratt");
		
		AcademicPaper stringMatchingPaper6 = new AcademicPaper("Fast Pattern Matching in Strings", 
				authorsStringMatching6, new GregorianCalendar(1977, 03, 21));


		/* This is a list of authors that we create for one paper. */
		ArrayList<String> authorsStringMatching7 = new ArrayList<String>();
		authorsStringMatching7.add("Donald E. Knuth");
		authorsStringMatching7.add("Vaughan R. Pratt");
		
		AcademicPaper stringMatchingPaper7 = new AcademicPaper("Fast Pattern Matching in Strings", 
				authorsStringMatching7, new GregorianCalendar(1977, 03, 21));

		/* This is a list of authors that we create for one paper. */
		ArrayList<String> authorsStringMatching8 = new ArrayList<String>();
		authorsStringMatching8.add("Donald E. Knuth");
		authorsStringMatching8.add("James H. Morris Jr.");
		authorsStringMatching8.add("Vaughan R. Pratt");
		
		AcademicPaper stringMatchingPaper8 = new AcademicPaper("Fast Pattern Matching in Strings The Third", 
				authorsStringMatching8, new GregorianCalendar(1987, 03, 21));
		
		/* The list is referenced to by the variable papers.  You can add to
		 * the list by invoking the add method in ArrayList.
		 */
		papers.add(stringMatchingPaper);
		papers.add(stringMatchingPaper2);
		papers.add(stringMatchingPaper3);
		papers.add(stringMatchingPaper4);
		papers.add(stringMatchingPaper5);
		papers.add(stringMatchingPaper6);
		papers.add(stringMatchingPaper7);
		papers.add(stringMatchingPaper8);

		/*
		 * Print out the unsorted list of papers.
		 * This uses an iterator to "iterate" through the list.
		 */
		System.out.println( "\n\nUnsorted List:" );

		Iterator<AcademicPaper> iterator = papers.iterator();

		while(iterator.hasNext())
		{
			// Note: This line of code will call toString of the AcademicPaper class.
			System.out.println(iterator.next());
		}
		


		/*
		 * Sort the list of papers using Collections.sort().
		 * Take a look at Collections.sort() in the API at
		 * http://download.oracle.com/javase/7/docs/api/java/util/Collections.html#sort%28java.util.List%29
		 * You need to call Collections.sort() and pass it the list of academic papers.
		 * SEE THE LAB HANDOUT FOR MORE INFORMATION.
		 */

		Collections.sort(papers);
		

		/*
		 * Print out the sorted list of papers.
		 */
		System.out.println("Sorted List:");
		/* HINT: Use an iterator the same way I used one above when
		 * the unsorted list of papers was printed.
		 */

		Iterator<AcademicPaper> iterator2 = papers.iterator();

		while(iterator2.hasNext())
		{
			// Note: This line of code will call toString of the AcademicPaper class.
			System.out.println(iterator2.next());
		}
		
		

		/* 
		 * Search for a particular academic paper in the list.
		 */
		System.out.println( "\n\nSearching" );
		AcademicPaper key = new AcademicPaper( "An Axiomatic Basis for Computer Programming",
				"C.A.R. Hoare", new GregorianCalendar(1969, 2, 1));
		System.out.println( "Key is " + key );

		/*
		 * Call Collections.binarySearch() to find the index of key.  
		 * Make sure you test the value of index to see if it negative, 
		 * which indicates that the key was not found in the list.
		 */
		
		int index = Collections.binarySearch(papers, key);

		/* 
		 * Print out whether the AcademicPaper was found or not and the index
		 * at which it was found.
		 * HINT: If index is negative print a statement saying that the
		 *       item searched for is not in the list.  Otherwise, print
		 *       out a statement telling that item was found in the list
		 *       and give the index of item in the list as well.
		 */

		if(index < 0){
			System.out.println("It ain't in the list bra");
		}
		else{
			System.out.println("Dude, the item was found at index " + index);
		}
		
		
		//EXTRA CREDIT
		for(AcademicPaper paper: papers){
			System.out.println(paper);
		}
	}
}